The method is in main.ipynb. The training data and test data is downloaded from Google drive. Run the code in sequence and the training model will be downloaded directly from tensorflow keras. 

The predict action can be achieved by using the data in val2014, and run the function: model.predict_generator and get the predicted labels.
